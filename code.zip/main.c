﻿#include <stdio.h>
#include "UI.h"

void main()

{
    load_users();
    load_planes();
    main_screen(); //进入主界面
}